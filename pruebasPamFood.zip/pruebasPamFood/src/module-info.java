module pruebasPamFood {
	requires java.desktop;
}